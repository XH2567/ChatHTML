#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
echo "Starting ChatHTML..."
./chat-html &
sleep 1
if command -v xdg-open &>/dev/null; then
    xdg-open http://127.0.0.1:8000
elif command -v open &>/dev/null; then
    open http://127.0.0.1:8000
else
    echo "Server started at http://127.0.0.1:8000"
fi
wait
