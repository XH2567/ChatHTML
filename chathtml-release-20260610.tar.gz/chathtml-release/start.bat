@echo off
cd /d "%~dp0"
echo Starting ChatHTML...
start "" http://127.0.0.1:8000
chat-html.exe
pause
