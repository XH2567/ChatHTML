#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
echo "Starting ChatHTML..."
./chat-html &
sleep 1
open http://127.0.0.1:8000
wait
